#ifndef _CONFIG_
#define _CONFIG_
#include "Gpio.h"
#include "delay.h"
#include "USART.h"
#include "WB_LCD.h"
#include "Controller.h"
#include "mpu6050.h"
#include "Timer.h"
#include "Debug.h"
#include "SDS.h"
struct TestStruct 
{
	uint16_t testduty1;
	uint16_t testduty2;
	uint16_t testduty;
};

#endif
